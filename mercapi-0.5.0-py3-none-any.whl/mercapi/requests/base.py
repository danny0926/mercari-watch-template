class RequestData:
    pass
